package days03;

/**
 * @author user
 * @date 2024. 1. 3. 오후 5:39:24
 * @subject 수식 표현 : 연산자 사용
 * @contents
 */
public class Ex10 {
	public static void main(String[] args) {
		          /* 1) x는 10보다 크다. 
						int x=5;
						System.out.println(x>10);
			      
			      // 2) x는 10보다 크고, 20보다 작다. 
						int y=5;
						System.out.println(10<y && y<20);
			      // 3) x는 2의 배수이다.  
							x % 2= 0;
			      
			      // 4) x는 2의 배수 또는 3의 배수이다. 
			      			x%2==0 || x%3==0
			      // 5) x는 2의 배수이지만 6의 배수는 아니다. 
			       			x%2==0 && x%6!=0
			      
			      // 6) 한 문자(ch)가  숫자이다.
			       * 		char ch='A'
			         		System.out.println((int)ch);
			      
			      // 7) 한 문자가 소문자이다. 
			       *     char ch= 'a';
			       * 	 97<= (int)ch && (int)ch <=122;
			      
			      // 8) 한 문자가 알파벳이다 ( 대문자이거나 또는 소문자 이니 ) 
			       * 	char ch= 'c';
			       *     System.out.println((65<=ch&& ch<=90)||(97<=ch && ch<=122);
			       * 	
			       *   
			       */
	}

}
