package days01;

import org.w3c.dom.ls.LSOutput;

/**
 * @author Sunny
 * @date 2023. 12. 29. - 오후 4:04:53
 * @subject \
 * @content 이름,나이를 저장할 변수를 선언하고 
 *   		출력하는 코딩.
 */
public class Ex04 {
	public static void main(String[] args) {
		String name="권맑음";
		int age = 31 ;
		System.out.println("제 이름은 \""+name +"\"입니다. 그리고 제 나이는 "+age+"살 입니다.");
		String name1="구본혁";
		int age1 = 29 ;
		System.out.println("제 이름은 \""+name1 +"\"입니다. 그리고 제 나이는 "+age1+"살 입니다.");
		// 3-2 . 출력형식 : 이름은 "권맑음"이고, 나이는 31살 입니다.
	  System.out.println();
		
	}

}
