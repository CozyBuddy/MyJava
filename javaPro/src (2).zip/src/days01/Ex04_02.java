package days01;

public class Ex04_02 {
	public static void main(String[] args) {
		// + 산술연산자(덧셈)
		System.out.println(3+5); // 8
		
		// +산술연산자 x, 문자열 연결 연산자
		System.out.println("3"+6+5); // 8
		System.out.println(3+6+"5"); // 8
	}

}
