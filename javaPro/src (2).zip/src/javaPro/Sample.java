package javaPro;
//The public type Sample must be defined in its own file
public class Sample {

	public static void main(String[] args) {
		System.out.println("권맑음");
	}
}
