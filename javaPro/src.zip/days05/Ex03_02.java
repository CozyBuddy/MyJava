package days05;

import java.util.Scanner;

public class Ex03_02 {
	public static void main(String[] args) {
		//임의의 수를 발생시키는 방법
		// 0.0 <= double <1.0;
		// for (int i =0 ; i <1000 ; i++){
		//System.out.println( (int)(Math.random()*3)+1);
	}
	
		
			/*switch (c) {
			case 1:
			case 2:
			case 3:
				System.out.println(b);
				if (c==b) {
					System.out.println("무승부");
				} else if (b<c) {
					System.out.println("승리");
				} else if ()
				
				break;

			default:
				System.out.println("입력 오류");
				break;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	} */


