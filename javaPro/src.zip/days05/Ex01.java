package days05;

public class Ex01 {
	public static void main(String[] args) {
		int [] kors = new int[3]; 
		 
	      // 초기화(입력)
	      kors[0] = 90;
	      kors[1] = 38;
	      kors[2] = 88;
	      
	      // 출력
	      for (int i = 0; i < kors.length; i++) {
	         System.out.printf("kors[%d]=%d\n",i, kors[i]);
	      }
		
	}

}
