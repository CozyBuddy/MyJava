package days04;

/**
 * @author user
 * @date 2024. 1. 4. 오후 3:40:09
 * @subject 
 * @contents
 */
public class Ex06 {
	public static void main(String[] args) {
		// for 문 선언 형식
		// for (초기식;조건식;증감식)
		for (int i = 0; i < args.length; i++) {
			
		}
		
		
	}

}
