package days01;

/**
 * @author Sunny
 * @date 2023. 12. 29. - 오후 4:49:10
 * @subject \
 * @content
 */
public class Ex05 {
	public static void main(String[] args) {
		//5:00
	}

}
