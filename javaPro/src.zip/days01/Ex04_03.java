package days01;

/**
 * @author Sunny
 * @date 2023. 12. 29. - 오후 4:27:11
 * @subject \
 * @content 
 */
public class Ex04_03 {
	public static void main(String[] args) {
		//표준 출력
		System.out.print("권맑음");
		System.out.print("구본혁");
		System.out.print("류영은");
		//Alt+Shift+A ??
		System.out.print("권맑음" + '\n');
		System.out.println(); //줄바꿈(개행)
		System.out.print("구본혁\n");
		System.out.print("류영은");
		
		//					format 출력형식
		// 					args = arguments 인자 ,매개변수, 파라미터
		// System.out.printf(null, args);
		//자바 함수(메서드) 제대로 사용하려면 반드시 3가지는 파악
		// 1. 해당 함수 역할(기능)
		//	2. 매개변수 
		//	3. 반환값(반환자료형)
		               
	}

}
