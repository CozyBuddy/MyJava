package days01;
// 자바 프로그램의 기본 구조 설명
// 반드시 시작객체로 사용할 클래스 1개 필요

/*줄바꿈 코딩
 * 2)'\n' 제어문자
*/
public class Review1 {
	public static void main(String[] args) {	
	String name = "홍길동";
	double height = 185.22;
	System.out.println("이름 : \""+"홍길동"+"\",키 :"+height+"cm");
	}
}
