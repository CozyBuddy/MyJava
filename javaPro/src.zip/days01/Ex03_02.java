package days01;


/**
 * @author Sunny
 * @date 2023. 12. 29. - 오후 3:15:52
 * @subject 변수와 상수
 * @content
 */
public class Ex03_02 {

	public static void main(String[] args) {
		//상수 
		// PI 상수 선언
		// const 상수
	
			final double PI = 3.141592; //상수화할떄 대문자로 명명하는게 관례
			// 변수 firstName
			// 상수 FIRST_NAME 가운데 글자 바뀔떄는 상수한정 언더바 넣음.
		/* 1. 저장공간, 초기화하면 변경X
		 * 수학관련 코딩
		 * 수학관련 코딩 * 3.141592
		 * 수학관련 코딩
		 * 수학관련 코딩
		 * 수학관련 코딩
		 * 수학관련 * 3.141592 코딩
		 * 수학관련 코딩
		 * 수학관련 코딩
		 * 수학관련 코 * 3.143592딩
		 * 수학관련 코딩
		 * 수학관련 코딩
		 * 수학 * 3.141592관련 코딩
		 * 수학관련 코딩
		 * 수학관련 코 * 3.141592딩
		 * 수학관련 코딩
		 * 수학관련 코딩
		 * 수학관련 코딩
		 * 수학관련 코딩
		 * 수학관 * 3.141592련 코딩
		 * */
			//The [final local variable] pi cannot be assigned. It must be blank and not using a compound assignment
			//pi= 3.14;
		


	}

}
