package days01 ;

import java.util.Iterator;


/**
 * @author Sunny
 * @date 2023. 12. 29. - 오후 2:32:58
 * @subject 수업 1일차 첫 번째 예제
 * @content JDK 11 설치 및 확인
 * 			자바 프로그램의 기본 구조 설명
 * 			자바 클래스 선언 형식
 *  		자바 함수(메서드) 선언 형식
 */
public class Ex01 {
	public static void main(String args[]) {
		System.out.println("Hello World!");
		int a = 10;
		int b = 12 ;
		String c= "*";
		for (int i = 0; i < 10; i++) {
			System.out.println(c);
			c +="*";
		}
			
		}
	}
	
