package days02;

public class Review {
   public static void main(String[] args) {
	
System.out.println(3+5+'0');
 // '0' -> 0으로 변환 방법 
 // '0'-48 = 0
   }
   
}
