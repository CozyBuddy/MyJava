package days02;

/**
 * @author user
 * @date 2024. 1. 2. 오후 12:16:12
 * @subject 변수(variable), 상수(constant), 리터럴(literal) 설명
 * @contents
 */
public class Ex05 {
	public static void main(String[] args) {
		/*
		 * 변수 :
		 * 상수 :
		 * 리터럴(literal) ? 그 자체가 값을 의미하는것 ex)true,false,'A' ->고정값
		 * 		
		 * int i = 100;
		 * 
		 */
		//리터럴과 접미사 
		// int 형 0
		// long 형 0
		// double 형 0
		// float 형 0
		
		// int i = 0.00;x
		int i =0;//[][][][]
		long j =0l; //[][][][][][][][]  // 0D ->double형 0 0F->float형
		float f = 3.14f;
		
		//long z = 10;
		
		
	}

}
