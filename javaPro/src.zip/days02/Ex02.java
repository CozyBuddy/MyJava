package days02;

public class Ex02 {
	// String name ;X
	public static void main(String[] args) {
		// 지역변수(local variable)는 반드시 초기화해야 사용할 수 있다.
		String name ="초기화" ; // [경고]The value of the local variable name is not used
		System.out.println(name); //[에러]The local variable name may not have been initialized
		
		//Ex02_02
	}

}
